package com.jarvis.assistant.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.ai.LocalLlmClient
import com.jarvis.assistant.core.LocalCommandParser
import com.jarvis.assistant.voice.SpeechManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Keeps "Jarvis, ..." wake-word listening alive even while another app is in
 * the foreground (e.g. watching a video). Android requires a foreground
 * service with a persistent notification for any app to keep using the
 * microphone while not visible on screen — this is that service.
 *
 * All the actual command handling lives here (not in MainActivity), so it
 * keeps working identically whether or not the app's UI is currently open.
 * When MainActivity is open, it binds to this service to mirror the chat
 * and the orb's state; when it's not, the service just speaks replies directly.
 */
class JarvisListenerService : Service() {

    interface JarvisEventListener {
        fun onUserSpeech(text: String)
        fun onAssistantReply(text: String)
        fun onListeningStateChanged(listening: Boolean)
        fun onSpeakStateChanged(speaking: Boolean)
    }

    inner class LocalBinder : Binder() {
        fun getService(): JarvisListenerService = this@JarvisListenerService
    }

    private val binder = LocalBinder()
    var listener: JarvisEventListener? = null

    private lateinit var speechManager: SpeechManager
    private lateinit var localLlm: LocalLlmClient
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private val systemPrompt =
        "Sen JARVIS'sin, telefonda çalışan kısa ve yardımsever bir Türkçe asistansın. Kısa ve net cevaplar ver."

    val isModelReady: Boolean
        get() = localLlm.isModelReady

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        speechManager = SpeechManager(applicationContext)
        speechManager.setSpeakStateListener { speaking -> listener?.onSpeakStateChanged(speaking) }
        localLlm = LocalLlmClient(applicationContext)
        startForegroundWithNotification()
        // No auto-start here — the mic only opens when the user taps the mic button.
    }

    private fun startForegroundWithNotification() {
        val channelId = "jarvis_listener"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "JARVIS Dinleme", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("JARVIS hazır")
            .setContentText("Konuşmak için mikrofon düğmesine bas.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    /** Called when the user taps the mic button — opens the mic for a single utterance. */
    fun startPushToTalk() {
        speechManager.startPushToTalk(
            onResult = { text -> handleCommand(text) },
            onListeningStateChanged = { listening -> listener?.onListeningStateChanged(listening) }
        )
    }

    /** Typed messages (from the chat input) skip the wake word — typing is already explicit intent. */
    fun sendTypedMessage(text: String) {
        handleCommand(text)
    }

    suspend fun importModel(uri: Uri): Boolean = localLlm.importModel(uri)

    fun cycleVoiceFromUI(): String = speechManager.cycleVoice()

    private fun handleCommand(command: String) {
        if (command.isBlank()) {
            listener?.onUserSpeech("Jarvis")
            val reply = "Efendim?"
            listener?.onAssistantReply(reply)
            speechManager.speak(reply)
            return
        }

        listener?.onUserSpeech(command)
        val normalized = command.trim().lowercase()

        if (normalized.contains("sesi değiştir") || normalized.contains("sesini değiştir") ||
            normalized.contains("ses değiştir")
        ) {
            val reply = speechManager.cycleVoice()
            listener?.onAssistantReply(reply)
            return
        }

        val localResult = LocalCommandParser.tryHandle(applicationContext, normalized)
        if (localResult != null) {
            listener?.onAssistantReply(localResult)
            speechManager.speak(localResult)
            return
        }

        if (!localLlm.isModelReady) {
            val reply = "Bunu anlayamadım ve henüz yerel model seçilmedi."
            listener?.onAssistantReply(reply)
            speechManager.speak(reply)
            return
        }

        serviceScope.launch {
            val reply = localLlm.reply(systemPrompt, command)
            listener?.onAssistantReply(reply)
            speechManager.speak(reply)
        }
    }

    override fun onDestroy() {
        speechManager.stopContinuousListening()
        speechManager.destroy()
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 1
    }
}
