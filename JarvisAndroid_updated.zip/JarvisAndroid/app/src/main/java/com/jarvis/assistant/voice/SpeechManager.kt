package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class SpeechManager(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var turkishVoices: List<android.speech.tts.Voice> = emptyList()
    private var voiceIndex = 0

    private val mainHandler = Handler(Looper.getMainLooper())
    private var continuousMode = false
    private var isListeningNow = false
    private var isSpeakingNow = false
    private var isSessionStarting = false
    private var consecutiveErrorCount = 0
    private var pendingFollowUp = false

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    // Callbacks used by continuous listening mode.
    private var onWakeResult: ((String) -> Unit)? = null
    private var onListeningStateChanged: ((Boolean) -> Unit)? = null
    private var onSpeakStateChanged: ((Boolean) -> Unit)? = null
    private var onErrorHeard: ((String) -> Unit)? = null

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("tr", "TR")
                turkishVoices = tts.voices
                    ?.filter { it.locale.language == "tr" }
                    ?.sortedBy { it.name }
                    .orEmpty()
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isSpeakingNow = true
                onSpeakStateChanged?.invoke(true)
            }
            override fun onDone(utteranceId: String?) {
                isSpeakingNow = false
                onSpeakStateChanged?.invoke(false)
                // Resume listening after JARVIS finishes talking, so it doesn't hear itself.
                if (continuousMode) mainHandler.post { startRecognizerCycle() }
            }
            override fun onError(utteranceId: String?) {
                isSpeakingNow = false
                onSpeakStateChanged?.invoke(false)
                if (continuousMode) mainHandler.post { startRecognizerCycle() }
            }
        })
    }

    /** Cycles to the next available Turkish TTS voice and speaks a short confirmation. */
    fun cycleVoice(): String {
        if (turkishVoices.size <= 1) {
            speak("Bu cihazda değiştirebileceğim başka bir Türkçe ses yok.")
            return "Bu cihazda tek bir Türkçe ses seçeneği var."
        }
        voiceIndex = (voiceIndex + 1) % turkishVoices.size
        tts.voice = turkishVoices[voiceIndex]
        val label = "Ses değiştirildi, seçenek ${voiceIndex + 1} / ${turkishVoices.size}."
        speak(label)
        return label
    }

    /** Registers a callback for TTS speaking state, independent of any listening mode. */
    fun setSpeakStateListener(listener: (Boolean) -> Unit) {
        onSpeakStateChanged = listener
    }

    /**
     * Starts always-on listening. [onWakeResult] only fires for utterances that
     * contain the wake word "jarvis" (already stripped out of the text). Every
     * other heard phrase is silently discarded and listening restarts automatically.
     */
    fun startContinuousListening(
        onWakeResult: (String) -> Unit,
        onListeningStateChanged: (Boolean) -> Unit,
        onSpeakStateChanged: (Boolean) -> Unit,
        onErrorHeard: (String) -> Unit
    ) {
        this.onWakeResult = onWakeResult
        this.onListeningStateChanged = onListeningStateChanged
        this.onSpeakStateChanged = onSpeakStateChanged
        this.onErrorHeard = onErrorHeard
        continuousMode = true
        startRecognizerCycle()
    }

    fun stopContinuousListening() {
        continuousMode = false
        isListeningNow = false
        isSessionStarting = false
        unmuteMicBeep()
        recognizer?.stopListening()
    }

    /**
     * Opens the mic once for a single utterance — used by the mic button (push-to-talk).
     * No wake word required, and the mic closes right after this one result/error;
     * nothing keeps listening in the background.
     */
    fun startPushToTalk(
        onResult: (String) -> Unit,
        onListeningStateChanged: (Boolean) -> Unit,
        onError: (() -> Unit)? = null
    ) {
        if (isListeningNow || isSessionStarting) return
        isSessionStarting = true

        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000)
        }

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListeningNow = true
                isSessionStarting = false
                onListeningStateChanged(true)
                mainHandler.postDelayed({ unmuteMicBeep() }, 120)
            }

            override fun onResults(results: Bundle) {
                isListeningNow = false
                isSessionStarting = false
                onListeningStateChanged(false)
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                onResult(matches?.firstOrNull().orEmpty())
            }

            override fun onError(error: Int) {
                isListeningNow = false
                isSessionStarting = false
                onListeningStateChanged(false)
                unmuteMicBeep()
                onError?.invoke()
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                muteMicBeep()
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        try {
            muteMicBeep()
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            isSessionStarting = false
            unmuteMicBeep()
            onError?.invoke()
        }
    }

    private fun startRecognizerCycle() {
        if (!continuousMode || isSpeakingNow || isListeningNow || isSessionStarting) return
        isSessionStarting = true

        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000)
        }

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListeningNow = true
                isSessionStarting = false
                consecutiveErrorCount = 0
                onListeningStateChanged?.invoke(true)
                // The start "beep" already played by the time we get here; unmute
                // right away so the user's own voice (and later TTS) isn't affected.
                mainHandler.postDelayed({ unmuteMicBeep() }, 120)
            }

            override fun onResults(results: Bundle) {
                isListeningNow = false
                isSessionStarting = false
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull().orEmpty()
                handleHeardText(text)
            }

            override fun onError(error: Int) {
                isListeningNow = false
                isSessionStarting = false
                unmuteMicBeep()

                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        // Normal in always-on mode — this happens constantly during silence.
                        // Don't flip the UI to "not listening" for this; it just restarts
                        // the recognizer session invisibly so the mic indicator stays steady.
                        consecutiveErrorCount = 0
                        restartSoon(150)
                    }
                    else -> {
                        onListeningStateChanged?.invoke(false)
                        consecutiveErrorCount++
                        if (consecutiveErrorCount >= 2) {
                            // The recognizer sometimes gets stuck after a few failures —
                            // recreate it from scratch rather than keep retrying the same instance.
                            recreateRecognizer()
                            consecutiveErrorCount = 0
                        }
                        restartSoon(900)
                    }
                }
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                // The "end" beep plays right as speech ends — mute it a beat before
                // the recognizer reports results/error.
                muteMicBeep()
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        try {
            muteMicBeep()
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            isSessionStarting = false
            unmuteMicBeep()
            restartSoon(800)
        }
    }

    private fun recreateRecognizer() {
        try { recognizer?.destroy() } catch (e: Exception) { /* ignore */ }
        recognizer = null
    }

    /** Best-effort suppression of the system "start/stop listening" beep tones. */
    private fun muteMicBeep() {
        try {
            audioManager?.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_MUTE, 0)
        } catch (e: Exception) { /* not all devices allow this — safe to ignore */ }
    }

    private fun unmuteMicBeep() {
        try {
            audioManager?.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_UNMUTE, 0)
        } catch (e: Exception) { /* ignore */ }
    }

    private fun handleHeardText(text: String) {
        if (text.isBlank()) {
            restartSoon(150)
            return
        }
        val lower = text.lowercase()
        if (lower.contains("jarvis") || lower.contains("carvis") || lower.contains("jarviz")) {
            onListeningStateChanged?.invoke(false)
            // Strip the wake word, keep whatever the user asked after it.
            val command = lower
                .replace("jarvis", "")
                .replace("carvis", "")
                .replace("jarviz", "")
                .trim(' ', ',', '.', '!', '?')
            onWakeResult?.invoke(command)
            // Don't auto-restart here — the app will restart listening once it's done
            // processing and speaking the reply, via onSpeakStateChanged(false).
        } else {
            // Not directed at JARVIS — stay quiet and keep listening.
            restartSoon(150)
        }
    }

    private fun restartSoon(delayMs: Long) {
        if (!continuousMode) return
        mainHandler.postDelayed({ startRecognizerCycle() }, delayMs)
    }

    /** Call this once the app is done handling a command, to resume always-on listening. */
    fun resumeListeningAfterReply() {
        if (continuousMode) mainHandler.post { startRecognizerCycle() }
    }

    fun speak(text: String) {
        val params = Bundle()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "jarvis_utterance")
    }

    fun destroy() {
        continuousMode = false
        unmuteMicBeep()
        recognizer?.destroy()
        tts.stop()
        tts.shutdown()
    }
}
