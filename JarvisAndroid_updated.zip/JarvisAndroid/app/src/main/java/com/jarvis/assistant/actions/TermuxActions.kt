package com.jarvis.assistant.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

/**
 * Gerçek Termux uygulamasına komut gönderir (Jarvis'in kendi terminali değil —
 * telefonda kurulu, bakımı yapılan gerçek Termux uygulaması).
 *
 * Gereksinimler (kullanıcı tarafında):
 * 1) Termux kurulu olmalı (F-Droid sürümü önerilir).
 * 2) Termux ayarlarından "Kilit ekranından/harici uygulamalardan komut çalıştırmaya izin ver"
 *    (allow-external-apps) açık olmalı — Termux'ta ~/.termux/termux.properties dosyasına
 *    `allow-external-apps = true` eklenip Termux yeniden başlatılarak da yapılabilir.
 *
 * Resmi API: https://github.com/termux/termux-app/wiki/RUN_COMMAND-Intent
 */
object TermuxActions {

    private const val TERMUX_PACKAGE = "com.termux"
    private const val TERMUX_SERVICE = "com.termux.app.RunCommandService"
    private const val TERMUX_HOME = "/data/data/com.termux/files/home"
    private const val TERMUX_BASH = "/data/data/com.termux/files/usr/bin/bash"

    fun runCommand(context: Context, command: String): String {
        val hasPermission = ContextCompat.checkSelfPermission(
            context, "com.termux.permission.RUN_COMMAND"
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasPermission) {
            return "Termux izni verilmemiş. Jarvis'i tamamen kapatıp yeniden aç " +
                "(izin isteme ekranı çıkacak) ya da telefon Ayarlar > Uygulamalar > Jarvis > " +
                "İzinler kısmından \"Termux komutları çalıştır\" iznini elle aç."
        }
        return try {
            val intent = Intent()
            intent.setClassName(TERMUX_PACKAGE, TERMUX_SERVICE)
            intent.action = "com.termux.RUN_COMMAND"
            intent.putExtra("com.termux.RUN_COMMAND_PATH", TERMUX_BASH)
            intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", command))
            intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", TERMUX_HOME)
            intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
            // 0 = yeni oturum açıp Termux'u öne getir, komutu ekranda göster.
            intent.putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0")
            ContextCompat.startForegroundService(context, intent)
            "Termux'ta çalıştırıyorum: $command"
        } catch (e: SecurityException) {
            "Termux'a komut gönderilemedi: izin reddedildi. Termux ayarlarından " +
                "\"harici uygulamalara izin ver\" (allow-external-apps) seçeneğini açman gerekiyor."
        } catch (e: Exception) {
            "Termux'a komut gönderemedim: ${e.message}. Termux kurulu mu kontrol et."
        }
    }
}
