package com.jarvis.assistant.terminal

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Downloads and unpacks Termux's official "bootstrap" archive — a minimal Linux userland
 * (bash, busybox/coreutils, and Termux's package manager `apt`) compiled for Android's
 * bionic libc. This is exactly what real Termux does on first launch.
 *
 * Layout mirrors Termux itself:
 *   filesDir/usr   -> PREFIX (binaries, libs, etc.)
 *   filesDir/home  -> HOME
 *
 * Requires internet access only the first time. After that, the environment is fully
 * offline (aside from `apt install <package>` if the user wants more tools).
 */
object BootstrapInstaller {

    private const val RELEASE_BASE = "https://github.com/termux/termux-packages/releases/latest/download"

    fun prefixDir(context: Context): File = File(context.filesDir, "usr")
    fun homeDir(context: Context): File = File(context.filesDir, "home")

    fun isInstalled(context: Context): Boolean =
        File(prefixDir(context), "bin/bash").exists()

    /** Maps the device's primary ABI to the filename Termux publishes for it. */
    private fun bootstrapArchName(): String {
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        return when {
            abi.startsWith("arm64") -> "aarch64"
            abi.startsWith("armeabi") -> "arm"
            abi == "x86_64" -> "x86_64"
            abi == "x86" -> "i686"
            else -> "aarch64"
        }
    }

    /**
     * Downloads the bootstrap zip and extracts it. Call from a background thread/coroutine.
     * [onProgress] receives 0..100.
     */
    suspend fun install(context: Context, onProgress: (Int) -> Unit = {}) = withContext(Dispatchers.IO) {
        val prefix = prefixDir(context)
        val home = homeDir(context)
        if (isInstalled(context)) return@withContext

        home.mkdirs()
        prefix.mkdirs()

        val zipUrl = "$RELEASE_BASE/bootstrap-${bootstrapArchName()}.zip"
        val tmpZip = File(context.cacheDir, "bootstrap.zip")

        downloadFile(zipUrl, tmpZip, onProgress)
        extractZip(tmpZip, prefix)
        tmpZip.delete()

        // Termux's bootstrap ships a SYMLINKS.txt describing symlinks that had to be
        // flattened into regular files inside the zip (zip has no reliable symlink support
        // across all tooling). Recreate them now.
        val symlinksFile = File(prefix, "SYMLINKS.txt")
        if (symlinksFile.exists()) {
            symlinksFile.forEachLine { line ->
                val parts = line.split("←", "<-")
                if (parts.size == 2) {
                    val target = parts[0].trim()
                    val linkPath = File(prefix, parts[1].trim())
                    linkPath.parentFile?.mkdirs()
                    if (!linkPath.exists()) {
                        try {
                            android.system.Os.symlink(target, linkPath.absolutePath)
                        } catch (_: Exception) {
                            // Best-effort; some devices/filesystems may not support symlinks.
                        }
                    }
                }
            }
            symlinksFile.delete()
        }

        // Everything under bin/ and libexec/ needs to be executable.
        File(prefix, "bin").walkTopDown().forEach { it.setExecutable(true, false) }
        File(prefix, "libexec").let { dir ->
            if (dir.exists()) dir.walkTopDown().forEach { it.setExecutable(true, false) }
        }

        onProgress(100)
    }

    private fun downloadFile(url: String, dest: File, onProgress: (Int) -> Unit) {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.instanceFollowRedirects = true
        connection.connect()
        val total = connection.contentLength
        connection.inputStream.use { input ->
            dest.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                var downloaded = 0
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    output.write(buffer, 0, read)
                    downloaded += read
                    if (total > 0) onProgress((downloaded * 90 / total).coerceAtMost(90))
                }
            }
        }
    }

    private fun extractZip(zipFile: File, outputDir: File) {
        ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(outputDir, entry.name)
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
}
