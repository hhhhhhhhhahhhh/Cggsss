package com.jarvis.assistant.terminal

import android.os.Bundle
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.jarvis.assistant.R
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import com.termux.view.TerminalView
import com.termux.view.TerminalViewClient
import kotlinx.coroutines.launch
import java.io.File

class TerminalActivity : AppCompatActivity() {

    private lateinit var terminalView: TerminalView
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private var session: TerminalSession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terminal)

        terminalView = findViewById(R.id.terminalView)
        progressBar = findViewById(R.id.terminalProgress)
        statusText = findViewById(R.id.terminalStatus)

        terminalView.setTextSize(36)

        val viewClient = object : TerminalViewClient {
            override fun onScale(scale: Float): Float = scale
            override fun onSingleTapUp(e: android.view.MotionEvent) {
                val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showSoftInput(terminalView, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
            override fun shouldBackButtonBeMappedToEscape(): Boolean = false
            override fun shouldEnforceCharBasedInput(): Boolean = true
            override fun shouldUseCtrlSpaceWorkaround(): Boolean = false
            override fun isTerminalViewSelected(): Boolean = true
            override fun copyModeChanged(copyMode: Boolean) {}
            override fun onKeyDown(keyCode: Int, e: android.view.KeyEvent, session: TerminalSession): Boolean = false
            override fun onKeyUp(keyCode: Int, e: android.view.KeyEvent): Boolean = false
            override fun onLongPress(event: android.view.MotionEvent): Boolean = false
            override fun readControlKey(): Boolean = false
            override fun readAltKey(): Boolean = false
            override fun readShiftKey(): Boolean = false
            override fun readFnKey(): Boolean = false
            override fun onCodePoint(codePoint: Int, ctrlDown: Boolean, session: TerminalSession): Boolean = false
            override fun onEmulatorSet() {}
            override fun logError(tag: String?, message: String?) {}
            override fun logWarn(tag: String?, message: String?) {}
            override fun logInfo(tag: String?, message: String?) {}
            override fun logDebug(tag: String?, message: String?) {}
            override fun logVerbose(tag: String?, message: String?) {}
            override fun logStackTraceWithMessage(tag: String?, message: String?, e: Exception?) {}
            override fun logStackTrace(tag: String?, e: Exception?) {}
        }
        // Set this immediately — Android can request an input connection as soon as the
        // window gains focus, before our (possibly async) session setup below finishes.
        terminalView.setTerminalViewClient(viewClient)

        if (BootstrapInstaller.isInstalled(this)) {
            startSession()
        } else {
            installBootstrapThenStart()
        }
    }

    private fun installBootstrapThenStart() {
        statusText.text = "Terminal ortamı ilk kez kuruluyor, internet gerekiyor…"
        progressBar.visibility = ProgressBar.VISIBLE
        lifecycleScope.launch {
            try {
                BootstrapInstaller.install(this@TerminalActivity) { percent ->
                    runOnUiThread { progressBar.progress = percent }
                }
                progressBar.visibility = ProgressBar.GONE
                statusText.text = ""
                startSession()
            } catch (e: Exception) {
                progressBar.visibility = ProgressBar.GONE
                statusText.text = "Kurulum başarısız: ${e.message}\n" +
                    "İnternet bağlantını kontrol edip tekrar dene."
            }
        }
    }

    private fun startSession() {
        val prefix = BootstrapInstaller.prefixDir(this)
        val home = BootstrapInstaller.homeDir(this)
        home.mkdirs()

        val shellPath = File(prefix, "bin/bash")
        val env = arrayOf(
            "PREFIX=${prefix.absolutePath}",
            "HOME=${home.absolutePath}",
            "PATH=${prefix.absolutePath}/bin",
            "LD_LIBRARY_PATH=${prefix.absolutePath}/lib",
            "TERM=xterm-256color",
            "LANG=en_US.UTF-8"
        )

        val client = object : TerminalSessionClient {
            override fun onTextChanged(changedSession: TerminalSession) {
                terminalView.onScreenUpdated()
            }

            override fun onTitleChanged(changedSession: TerminalSession) {}

            override fun onSessionFinished(finishedSession: TerminalSession) {
                statusText.text = "Oturum sonlandı."
            }

            override fun onCopyTextToClipboard(session: TerminalSession, text: String) {}
            override fun onPasteTextFromClipboard(session: TerminalSession?) {}
            override fun onBell(session: TerminalSession) {}
            override fun onColorsChanged(session: TerminalSession) {}
            override fun onTerminalCursorStateChange(state: Boolean) {}
            override fun getTerminalCursorStyle(): Int? = null
            override fun logError(tag: String?, message: String?) {}
            override fun logWarn(tag: String?, message: String?) {}
            override fun logInfo(tag: String?, message: String?) {}
            override fun logDebug(tag: String?, message: String?) {}
            override fun logVerbose(tag: String?, message: String?) {}
            override fun logStackTraceWithMessage(tag: String?, message: String?, e: Exception?) {}
            override fun logStackTrace(tag: String?, e: Exception?) {}
        }

        val newSession = TerminalSession(
            shellPath.absolutePath,
            home.absolutePath,
            arrayOf(shellPath.absolutePath, "-l"),
            env,
            /* transcriptRows */ 2000,
            client
        )
        session = newSession
        terminalView.attachSession(newSession)
        terminalView.requestFocus()
    }

    override fun onDestroy() {
        super.onDestroy()
        session?.finishIfRunning()
    }
}
