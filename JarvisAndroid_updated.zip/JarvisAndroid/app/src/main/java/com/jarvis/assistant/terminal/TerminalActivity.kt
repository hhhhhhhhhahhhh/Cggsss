package com.jarvis.assistant.terminal

import android.os.Bundle
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.jarvis.assistant.R
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import com.termux.view.TerminalView
import kotlinx.coroutines.launch
import java.io.File

class TerminalActivity : AppCompatActivity() {

    private lateinit var terminalView: TerminalView
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private var session: TerminalSession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terminal)

        terminalView = findViewById(R.id.terminalView)
        progressBar = findViewById(R.id.terminalProgress)
        statusText = findViewById(R.id.terminalStatus)

        terminalView.setTextSize(36)
        terminalView.requestFocus()

        if (BootstrapInstaller.isInstalled(this)) {
            startSession()
        } else {
            installBootstrapThenStart()
        }
    }

    private fun installBootstrapThenStart() {
        statusText.text = "Terminal ortamı ilk kez kuruluyor, internet gerekiyor…"
        progressBar.visibility = ProgressBar.VISIBLE
        lifecycleScope.launch {
            try {
                BootstrapInstaller.install(this@TerminalActivity) { percent ->
                    runOnUiThread { progressBar.progress = percent }
                }
                progressBar.visibility = ProgressBar.GONE
                statusText.text = ""
                startSession()
            } catch (e: Exception) {
                progressBar.visibility = ProgressBar.GONE
                statusText.text = "Kurulum başarısız: ${e.message}\n" +
                    "İnternet bağlantını kontrol edip tekrar dene."
            }
        }
    }

    private fun startSession() {
        val prefix = BootstrapInstaller.prefixDir(this)
        val home = BootstrapInstaller.homeDir(this)
        home.mkdirs()

        val shellPath = File(prefix, "bin/bash")
        val env = arrayOf(
            "PREFIX=${prefix.absolutePath}",
            "HOME=${home.absolutePath}",
            "PATH=${prefix.absolutePath}/bin",
            "LD_LIBRARY_PATH=${prefix.absolutePath}/lib",
            "TERM=xterm-256color",
            "LANG=en_US.UTF-8"
        )

        val client = object : TerminalSessionClient {
            override fun onTextChanged(changedSession: TerminalSession) {
                terminalView.onScreenUpdated()
            }

            override fun onTitleChanged(changedSession: TerminalSession) {}

            override fun onSessionFinished(finishedSession: TerminalSession) {
                statusText.text = "Oturum sonlandı."
            }

            override fun onCopyTextToClipboard(session: TerminalSession, text: String) {}
            override fun onPasteTextFromClipboard(session: TerminalSession?) {}
            override fun onBell(session: TerminalSession) {}
            override fun onColorsChanged(session: TerminalSession) {}
            override fun onTerminalCursorStateChange(state: Boolean) {}
            override fun getTerminalCursorStyle(): Int? = null
            override fun logError(tag: String?, message: String?) {}
            override fun logWarn(tag: String?, message: String?) {}
            override fun logInfo(tag: String?, message: String?) {}
            override fun logDebug(tag: String?, message: String?) {}
            override fun logVerbose(tag: String?, message: String?) {}
            override fun logStackTraceWithMessage(tag: String?, message: String?, e: Exception?) {}
            override fun logStackTrace(tag: String?, e: Exception?) {}
        }

        val newSession = TerminalSession(
            shellPath.absolutePath,
            home.absolutePath,
            arrayOf(shellPath.absolutePath, "-l"),
            env,
            /* transcriptRows */ 2000,
            client
        )
        session = newSession
        terminalView.attachSession(newSession)
    }

    override fun onDestroy() {
        super.onDestroy()
        session?.finishIfRunning()
    }
}
