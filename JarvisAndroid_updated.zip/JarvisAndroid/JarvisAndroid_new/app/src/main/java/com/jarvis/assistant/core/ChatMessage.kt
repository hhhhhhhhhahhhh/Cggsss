package com.jarvis.assistant.core

data class ChatMessage(
    val text: String,
    val isUser: Boolean
)
